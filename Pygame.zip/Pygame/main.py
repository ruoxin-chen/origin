# USYD CODE CITATION ACKNOWLEDGEMENT
# I declare that part of the following code has been taken from the
# website titled:"Space Invaders Part 5 - Alien Bullets" and it is not my own work.
# 
# Original URL
# http://codingwithruss.com/pygame/invaders/alien-bullets.html 
# Last access April, 2022

import pygame 
import random 
from pygame import mixer
import time

# Initialise Pygame 
pygame.init()

# Create the screen 
screen = pygame.display.set_mode((800, 600)) # Width and height of the screen

# Background
background = pygame.image.load('space.png').convert() # Convert the image to the same pixel format as the screen to improve performance

# Title of the window
pygame.display.set_caption("Space Invaders")

# Background sound 
mixer.music.load('background.wav') # Load music
mixer.music.play(-1) # Play music on loop 

# Create dinosaur class
class Dinosaur(pygame.sprite.Sprite):
    def __init__(self, x, y): # Initialise each new instance of the class
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("dinosaur.png").convert_alpha() # Contains transparency to the image 
        self.rect = self.image.get_rect() # Draws a rectangle around the image
        self.rect.center = [x, y] # Set the position of the center of the rect object
        self.last_shot = pygame.time.get_ticks() # The time when the bullet is created

    # Sprite movement
    def update(self): 
        speed = 5
        key = pygame.key.get_pressed() # Returns a tuple representing the pressed state for keys
        if key[pygame.K_LEFT] and self.rect.left > 0: # Left arrow pressed and the left side of the rect object is within the screen boundary
            self.rect.x -= speed # Change direction
        if key[pygame.K_RIGHT] and self.rect.right < 800: # Right arrow pressed and the right side of the rect object is within the screen boundary
            self.rect.x += speed # Change direction
        
        # Record current time
        time_now = pygame.time.get_ticks()

        # Shooting
        if key[pygame.K_SPACE] and time_now - self.last_shot > 700: # Check whether 700 milliseconds passed before the last shot
            bullet = Bullets(self.rect.centerx, self.rect.top) # Create an instance
            bullet_group.add(bullet) # Add sprite to the bullet_group
            bullet_sound = mixer.Sound('shot.wav')  
            bullet_sound.play() # Play the shooting sound effect every time the bullet is shot 
            self.last_shot = time_now # Update the last_shot variable

# Create bullet class
class Bullets(pygame.sprite.Sprite): 
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("fire.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.font = pygame.font.SysFont('arial', 28) # Create a font object from the system fonts

    def update(self):
        self.rect.y -= 3 # The bullet moves up by decreasing the y-coordinate
        if self.rect.bottom < 0: # When the bottom of the bullet goes off the screen
            self.kill() # Kill the instance
        if pygame.sprite.spritecollide(self, ufo_group, True): # Check if any ufo intersects with the bullet
            self.kill() # Removes the bullet 
            collision_sound = mixer.Sound('explosion.wav') 
            collision_sound.play() # Play the explosion sound effect every time a ufo is shot
            reset_ufo() # Call the reset_ufo function
            update_score(True) # Call the update_score function

# Display score 
score = 0 
def update_score(a):
    global score 
    if a: # if True 
        score += 10
    font = pygame.font.SysFont('arial', 28)
    text = font.render("Score: " + str(score), True, (255, 255, 255)) # Render the text into an image, (255. 255. 255) indicates white
    screen.blit(text, (20,20)) # Blit the text image to the screen

# Display "Game Over"
def game_over_text():
    font = pygame.font.SysFont('arial', 64)
    game_over_text = font.render("GAME OVER", True, (255, 255, 255))
    screen.blit(game_over_text, (200, 250))
    pygame.display.flip() # Update the entire Surface to the screen
    pygame.time.delay(4000) # Pause the program for 4 seconds 
            
# Create ufo class 
class Ufos(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("ufo.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.change_x = 1 # The speed of moving right
        self.change_y = 30 # The speed of moving down

    def update(self):
        self.rect.x += self.change_x # The x-coordinate of ufo changes by its speed 
        if self.rect.x > 736: # Reaches the right end
            self.change_x = - 1 # Change direction
            self.rect.y += self.change_y
        if self.rect.x < 0: # Reaches the left end
            self.change_x = 1 # Change direction
            self.rect.y += self.change_y

# Create sprite groups to keep sprites inside organised Groups
dinosaur_group = pygame.sprite.Group()
bullet_group = pygame.sprite.Group() 
ufo_group = pygame.sprite.Group()

# Create ufos
def create_ufos():
    num_of_ufo = 12
    for i in range(num_of_ufo): # Create 12 ufos
        ufox = random.randint(32, 768) # Randomly generates its x- and y- coordiante
        ufoy = random.randint(100, 200)
        ufo = Ufos(ufox, ufoy) # Instance of the ufo class
        ufo_group.add(ufo) # Add ufo to ufo_group

create_ufos()

# Reset ufos 
def reset_ufo():
    ufox = random.randint(32, 768)
    ufoy = random.randint(-50, 0) # Slightly above the screen, creating an illusion of coming down from the top
    ufo = Ufos(ufox, ufoy)  
    ufo_group.add(ufo)

# Create player
dinosaur = Dinosaur(400, 520) # x- and y-coordinate of the player
dinosaur_group.add(dinosaur) # Add dinosaur to dinosaur_group

# Main game loop
running = True 
while running: 
   # RGB - Red, Green, Blue 
    screen.fill((0, 0, 0)) # Black screen
    # Background Image
    screen.blit(background, (0, 0)) # Blit the background image on top of the black screen
    update_score(False)
    # Get events from the queue and loop through all events  
    for event in pygame.event.get():  
        if event.type == pygame.QUIT:
            running = False # Terminate the while loop when there is a quit event
    # Game Over
    if pygame.sprite.spritecollide(dinosaur, ufo_group, False): # Check if any ufo hits the player
        dinosaur.kill() # Remove the dinosaur 
        game_over_text() # Display "Game Over"
        break 

    #Update the player sprite
    dinosaur.update()

    # Update sprite groups
    bullet_group.update()
    ufo_group.update()

    # Draw sprite groups 
    dinosaur_group.draw(screen)
    bullet_group.draw(screen)
    ufo_group.draw(screen)

    # Update the whole screen
    pygame.display.update()  

pygame.quit()